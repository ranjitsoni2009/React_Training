import axios from "axios";

export function IncrementFollowers(index){
    return {
        type:'INCREMENT_FOLLOWERS',
        index:index
    }
}

export function DeleteUser(){
    return {
        type:'REMOVE_USER'
    }
}

export function RatePost(){
    return {
        type:'RATE_POST'
    }
}

export function fetchUsersData(){
    console.log('fetchUsersData called...');
    var promise = axios.get('https://api.myjson.com/bins/t15w0');
    return dispatch =>{
        promise.then(
            (response) =>{dispatch({type:'FETCH_USERS', response : response.data})},
            () =>{}
        );
    }
}