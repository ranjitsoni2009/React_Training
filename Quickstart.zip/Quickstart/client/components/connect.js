import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as allactions from '../actions/actions';
import MainComponent from './main.component';


function mapDispatchToProps(dispatch){
    return bindActionCreators(allactions, dispatch);
}

function mapStateToProps(storeData){
    return{
        allUsers:storeData.users,
        allPosts:storeData.posts
    }
}

var app = connect(mapStateToProps, mapDispatchToProps)(MainComponent)
export default app;