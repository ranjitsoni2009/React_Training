import React, {Component} from 'react'

export default class MainComponent extends Component{
    render(){
        console.log(this.props.allUsers);
        return  <div>
                <h1>Main Component</h1>
                {React.cloneElement(this.props.children, this.props)}
                </div>
    }
}