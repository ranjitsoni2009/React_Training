import React from 'react';
import {Component} from 'react';
import UserThumbnailComponent from './userthumbnail'

export default class UsersComponent extends Component{

    render(){
        console.log('Render->>',this.props.allUsers);
        let userTobeCreated = this.props.allUsers.map((user, index) => <UserThumbnailComponent key={user.id} {...this.props} userDetails={user} userindex={index} />);
        return  <div>
                    <h1>Users Component</h1>
                    <div className="container">{userTobeCreated}</div>
                </div>
    }
} 