import React from 'react';
import {Component} from 'react'

export default class UserDetailsComponent extends Component{
    render(){
        let userId = this.props.params.id;
        let user = this.props.allUsers.find(user => user.id == userId);
        let userIndex = this.props.allUsers.findIndex(user => user.id == userId);
        return <div>
            <h1>User Details Component</h1>
            <div>
                    {user.login}<br/>
                    <img src={user.avatar_url} width="500px" height="500px"></img>
            <br />
            <button className="btn btn-success" onClick={this.props.IncreamentFollowers.bind(this, userIndex)}>
            <span className="glyphicon glyphicon-user">{user.followers}</span></button>
            </div>
        </div>
    }
}