import React from 'react';
import {Component} from 'react';
import {Link} from 'react-router'; 

export default class UserThumbnailComponent extends Component{

    render(){
        return <div col-md-3> 
            
                <Link to={"userDetails/"+this.props.userDetails.id}>
                    {this.props.userDetails.login}<br/>
                    <img src={this.props.userDetails.avatar_url} width="100px" height="100px"></img>
                </Link>
            <br></br><button className="btn btn-success" onClick={this.props.IncreamentFollowers.bind(this, this.props.userindex)}>
            <span className="glyphicon glyphicon-user">{this.props.userDetails.followers}</span></button>
        </div>
    }
} 