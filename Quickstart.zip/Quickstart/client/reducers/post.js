export default function posts(defStore=[], action){
    switch(action.type){
        case 'RATE_POST':
            console.log("within post reducers");
            return defStore;
        default:
            console.log("within post reducers default");
            return defStore;
    }
}