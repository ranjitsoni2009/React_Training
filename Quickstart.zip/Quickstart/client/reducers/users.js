export default function users(defStore=[], action){
    switch(action.type){
        case 'INCREAMENT_FOLLOWERS':
            console.log("within users reducers :"+action.index);
            var newData = [...defStore.slice(0, action.index),
            {...defStore[action.index], followers:defStore[action.index].followers+1},
            ...defStore.slice(action.index+1)
        ];
           
            return newData;
        case 'REMOVE_USER':
            console.log("within users reducers");
            return defStore;
        default:
            console.log("within user reducers default");
            return defStore;
    }
}