export function IncreamentFollowers(index){ //Action Creator
    return{
        type : 'INCREAMENT_FOLLOWERS', //Action
        index:index
    }
}

export function DeleteUser(){ //Action Creator
    return{
        type : 'REMOVE_USER' //Action
    }
}

export function RatePost(){ //Action Creator
    return{
        type:'RATE_POST' //Action
    }
}